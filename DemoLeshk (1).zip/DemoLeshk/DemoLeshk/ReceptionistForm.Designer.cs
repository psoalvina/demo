﻿namespace DemoLeshk
{
    partial class ReceptionistForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.exitButton = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.fullnameTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.passportnumberTextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.roomTextBox = new System.Windows.Forms.TextBox();
            this.enrtydateTextBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.departuredateTextBox = new System.Windows.Forms.TextBox();
            this.inputButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // exitButton
            // 
            this.exitButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exitButton.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            this.exitButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.exitButton.Location = new System.Drawing.Point(837, 12);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(135, 40);
            this.exitButton.TabIndex = 2;
            this.exitButton.Text = "Выход";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.SystemColors.Control;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(307, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(363, 45);
            this.label2.TabIndex = 7;
            this.label2.Text = "Регистрация гостя";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.SystemColors.Control;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            this.label3.Location = new System.Drawing.Point(172, 165);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(203, 36);
            this.label3.TabIndex = 9;
            this.label3.Text = "ФИО";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // fullnameTextBox
            // 
            this.fullnameTextBox.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            this.fullnameTextBox.Location = new System.Drawing.Point(383, 166);
            this.fullnameTextBox.Name = "fullnameTextBox";
            this.fullnameTextBox.Size = new System.Drawing.Size(199, 35);
            this.fullnameTextBox.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.Control;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            this.label1.Location = new System.Drawing.Point(172, 220);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(203, 36);
            this.label1.TabIndex = 11;
            this.label1.Text = "Номер паспорта";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // passportnumberTextBox
            // 
            this.passportnumberTextBox.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            this.passportnumberTextBox.Location = new System.Drawing.Point(383, 221);
            this.passportnumberTextBox.Name = "passportnumberTextBox";
            this.passportnumberTextBox.Size = new System.Drawing.Size(199, 35);
            this.passportnumberTextBox.TabIndex = 10;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.SystemColors.Control;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            this.label4.Location = new System.Drawing.Point(172, 275);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(203, 36);
            this.label4.TabIndex = 13;
            this.label4.Text = "Комната";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // roomTextBox
            // 
            this.roomTextBox.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            this.roomTextBox.Location = new System.Drawing.Point(383, 275);
            this.roomTextBox.Name = "roomTextBox";
            this.roomTextBox.Size = new System.Drawing.Size(199, 35);
            this.roomTextBox.TabIndex = 12;
            // 
            // enrtydateTextBox
            // 
            this.enrtydateTextBox.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            this.enrtydateTextBox.Location = new System.Drawing.Point(383, 326);
            this.enrtydateTextBox.Name = "enrtydateTextBox";
            this.enrtydateTextBox.Size = new System.Drawing.Size(199, 35);
            this.enrtydateTextBox.TabIndex = 14;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.SystemColors.Control;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            this.label5.Location = new System.Drawing.Point(172, 326);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(203, 36);
            this.label5.TabIndex = 15;
            this.label5.Text = "Дата въезда";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.SystemColors.Control;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            this.label6.Location = new System.Drawing.Point(172, 377);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(203, 36);
            this.label6.TabIndex = 17;
            this.label6.Text = "Дата выезда";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // departuredateTextBox
            // 
            this.departuredateTextBox.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            this.departuredateTextBox.Location = new System.Drawing.Point(383, 377);
            this.departuredateTextBox.Name = "departuredateTextBox";
            this.departuredateTextBox.Size = new System.Drawing.Size(199, 35);
            this.departuredateTextBox.TabIndex = 16;
            // 
            // inputButton
            // 
            this.inputButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.inputButton.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            this.inputButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.inputButton.Location = new System.Drawing.Point(599, 165);
            this.inputButton.Name = "inputButton";
            this.inputButton.Size = new System.Drawing.Size(170, 246);
            this.inputButton.TabIndex = 18;
            this.inputButton.Text = "Ввод";
            this.inputButton.UseVisualStyleBackColor = true;
            this.inputButton.Click += new System.EventHandler(this.inputButton_Click);
            // 
            // ReceptionistForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 561);
            this.Controls.Add(this.inputButton);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.departuredateTextBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.enrtydateTextBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.roomTextBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.passportnumberTextBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.fullnameTextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.exitButton);
            this.Name = "ReceptionistForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ReceptionistForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox fullnameTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox passportnumberTextBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox roomTextBox;
        private System.Windows.Forms.TextBox enrtydateTextBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox departuredateTextBox;
        private System.Windows.Forms.Button inputButton;
    }
}